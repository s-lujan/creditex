<?php $__env->startSection('title', 'Actualizar Cuenta'); ?>

<?php $__env->startSection('content'); ?>
  <div class="conatainer">
      <form class=class="form-group" action="/cuentas/<?php echo e($cuenta->id); ?>" method="post" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="">Nombre de Cuenta</label>
          <input type="text" name="Nombre" value="<?php echo e($cuenta->name); ?>" class="form-control">
        </div>
        <div class="form-group">
          <label for="">Descripcion de Cuenta</label>
          <input type="text" name="Descripcion" value="<?php echo e($cuenta->descripcion); ?>" class="form-control">
        </div>
        <div class="form-group">
          <label for="">Interes</label>
          <input type="text" name="Interes" value="<?php echo e($cuenta->interes); ?>" class="form-control">
        </div>
      <button type="submit" class="btn btn-primary">Actualizar</button>
      </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Creditex\resources\views/cuentas/edit.blade.php ENDPATH**/ ?>