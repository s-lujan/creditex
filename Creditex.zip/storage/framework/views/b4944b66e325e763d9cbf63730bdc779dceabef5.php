<?php $__env->startSection('title', 'Cuentas'); ?>

<?php $__env->startSection('content'); ?>
  <div class="col-sm">
    <div class="card text-center">
      <div class="card text-white bg-success mb-3">
        <div class="card-body">
          <h1 class="card-title">Listado de Cuentas</h1>
        </div>
      </div>
    </div>
  </div>
  <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm">
        <div class="card text-center">
          <div class="card text-white bg-dark mb-3">
            <div class="card-body">
              <h5 class="card-title"><?php echo e($cuenta->name); ?></h5>
              <a href="/cuentas/<?php echo e($cuenta->id); ?>" class="btn btn-primary">Detalles</a>
              <a href="<?php echo e(route('cuenta-delete', $cuenta->id)); ?>" class="btn btn-danger">Eliminar</a>
            </div>
          </div>
        </div>
      </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Creditex\resources\views/cuentas/index.blade.php ENDPATH**/ ?>