<?php $__env->startSection('title', 'Agregar Cuenta'); ?>

<?php $__env->startSection('content'); ?>
  <div class="conatainer">
      <form class=class="form-group" action="/transacciones" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="">Cantidad</label>
          <input type="text" name="Cantidad" class="form-control">
        </div>
        <div class="form-group">
          <label for="">Descripcion de la Transacciones</label>
          <input type="text" name="Descripcion" class="form-control">
        </div>
        <div class="form-group">
          <label for="">Id cuenta</label>
          <input type="text" name="Cuenta_id" class="form-control">
        </div>
      <button type="submit" class="btn btn-primary">Crear</button>
      </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Creditex\resources\views/transacciones/create.blade.php ENDPATH**/ ?>