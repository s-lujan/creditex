<footer class="container-fluid">
  <div class="row">
    <div class="col-md-4">
      <h3>Creditex</h3>
      <p>Medicasa es la aplicacion mas innovadora del mercado en la parte de los medicamentos y la atencion a nuestros clientes.</p>
    </div>
    <div class="col-md-4">
      <h3>Desarollado por:</h3>
      <div class="author-info">
        <img src="https://i.pinimg.com/originals/8f/de/e4/8fdee4c475f7bfd53a89a06bd1168d77.jpg" alt="" class="avatar">
        <p><a href="#">@HakunaMatata</a>Estudiante de Ing. Sistemas y computacion de la Universidad Tecnologica de Pereira</p>
      </div>
    </div>
      <div class="col-md-4">
        <h3>Siguenos</h3>
        <ul class="redes">
          <li>
            <a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
          </li>
          <li>
            <a href="#"><i class="fa fa-instagram fa-2x"></i></a>
          </li>
          <li>
            <a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
          </li>
          <li>
            <a href="#"><i class="fa fa-google-plus-square fa-2x"></i></a>
          </li>
          <li>
            <a href="#"><i class="fa fa-linkedin-square fa-2x"></i></a>
          </li>
          <li>
            <a href="#"><i class="fa fa-youtube-square fa-2x"></i></a>
          </li>
        </ul>
        <h3>Escribenos:</h3>
        <i class="fa fa-envelope" aria-hidden="true"></i><a href="#">medicasa@gmail.com</a>
    </div>
  </div>
</footer>
<?php /**PATH C:\laragon\www\Creditex\resources\views/cuentas/footer.blade.php ENDPATH**/ ?>