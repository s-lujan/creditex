<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Creditex - <?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
    <nav class="navbar navbar-dark bg-info">
      <a href="<?php echo e(url('/')); ?>" class="navbar-brand">CREDITEX</a>
      <div class="btn-group" role="group" aria-label="Basic example">
        <a href="<?php echo e(url('/cuentas/create')); ?>" class="btn btn-warning btn-md">Agregar Cuenta</a>
      </div>
    </nav>
    <div class="container">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
  </body>
</html>
<?php /**PATH C:\laragon\www\Creditex\resources\views/layouts/app.blade.php ENDPATH**/ ?>