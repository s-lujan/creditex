<?php $__env->startSection('title', 'Destalles de la Cuenta'); ?>

<?php $__env->startSection('content'); ?>
  <div class="col-sm">
    <div class="card text-center">
      <div class="card text-white bg-success mb-3">
        <div class="card-body">
          <h1 class="card-title">Detalles de la Cuentas</h1>
          <a href="/transacciones/create" class="btn btn-warning btn-md">Agregar Transaccion</a>
        </div>
      </div>
    </div>
  </div>
  <div class="text-center">
    <h1 class="card-title">Nombre de la cuenta: <?php echo e($cuenta->name); ?></h1>
    <h5 class="card-title">Descripcion de la cuenta: <?php echo e($cuenta->descripcion); ?></h5>
    <h5 class="card-title">Interes de la cuenta: <?php echo e($cuenta->interes); ?>%</h5>
    <h5 class="card-title">Identificador de la cuenta: <?php echo e($cuenta->id); ?></h5>
  </div>
  <div class="container text-center">
    <div class="page">
      <div class="table-responsive">
        <h3>Comprobantes</h3>
        <table class="table table-striped table-hover table-bordered">
          <thead>
            <tr>
              <th>Cantidad</th>
              <th>Descripcion</th>
              <th>Fecha</th>
              <th>Interes</th>
              <th>Balance</th>
              <th>Quitar</th>
            </tr>
          </thead>
          <body>
            <?php
            $total=0;
             ?>
            <?php $__currentLoopData = $transacciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($transaccion->cuenta_id == $cuenta->id): ?>
                <?php if($transaccion->Cantidad > 0): ?>
                  <tr>
                  <td><?php echo e($transaccion->Cantidad); ?></td>
                  <td><?php echo e($transaccion->descripcion); ?></td>
                  <td><?php echo e($transaccion->created_at); ?></td>
                  <td>$<?php echo e(number_format(($cuenta->interes / 100) * $transaccion->Cantidad)); ?></td>
                  <td>$<?php echo e(number_format((($cuenta->interes / 100) * $transaccion->Cantidad)+ $transaccion->Cantidad,2)); ?></td>
                  <td><a href="<?php echo e(route('transaccion-delete', $transaccion->id)); ?>" class="btn btn-danger">Eliminar</td>
                  </tr>
                  <?php
                    $total +=(($cuenta->interes / 100) * $transaccion->Cantidad)+ $transaccion->Cantidad
                   ?>
                <?php else: ?>
                  <tr>
                  <td><?php echo e($transaccion->Cantidad); ?></td>
                  <td><?php echo e($transaccion->descripcion); ?></td>
                  <td><?php echo e($transaccion->created_at); ?></td>
                  <td>$0.00</td>
                  <td>$<?php echo e(number_format($transaccion->Cantidad,2)); ?></td>
                  <td><a href="<?php echo e(route('transaccion-delete', $transaccion->id)); ?>" class="btn btn-danger">Eliminar</td>
                  </tr>
                  <?php
                    $total +=$transaccion->Cantidad
                   ?>
                <?php endif; ?>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </body>
        </table><hr>
          <h3>
            <span class="label label-success">
               Total:$ <?php echo e(number_format($total,2)); ?>

            </span>
          </h3>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Creditex\resources\views/cuentas/show.blade.php ENDPATH**/ ?>